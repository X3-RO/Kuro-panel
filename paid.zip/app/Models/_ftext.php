<?php

namespace App\Models;

use CodeIgniter\Model;

class _ftext extends Model
{
    /*=================================================================*/
    
    protected $table      = '_ftext';
    protected $allowedFields = ['_status','_ftext'];
    
}