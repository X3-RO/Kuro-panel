2018/04/27
		- Source control moved to github

2011/07/09
		- html & cosmetic changes in examples
		- released version 4.2.2

2011/07/08
		- fixes for arin (bug #3339783)
		- fixed .nl handler (bug #3314404)
		- fixed .ae whois server (bug #3354286)
		- fixed bug #3333558
		- .uk handler improvement (partial patch #3314417)
		- added support for .gt domains (request #3353926)
		- cosmetic fixes to many handlers (removed unuseful
		  spaces, removed change history, regyinfo position
		  unification,...)
		- cira.ca,nicline are non UTF8

2011/06/26
		- added handler for gandi (request #3155752)
		- added handler for .cl
		- corrected utf-8 support for .hu, .br and ripe
		- fixes for .pl, .org.za, .be, .cz, .de, .fj, .it, .ch
		  handlers
		- nameservers are automatically searched if missing

2011/06/24
		- fixed .be handler (bug #3307363)
		- fixed ip.lacnic handler array handling
		- fixed .eu hanlder (bug #3297823)
		- fixed .ae handler (bug #3181964)
		- fixed .uk handler (partial patch # 3314417)
		- fixed .ru handler (bug #3178123)
		- added handler for .ir

2011/01/26
		- fixed .se handler (bug #3165639)

2011/01/24
		- fixed .pe server (bug #3164251)

2011/01/17
		- fixed .co handler (bug #3159317)
		- fixed .ca handler (bug #3141475)

2010/12/06
		- fixed .ca handler

2010/12/03
		- fixed .pl handler

2010/11/29
		- fixed .de handler

2010/11/22
		- added handler for corporatedomains (Kyle Brost)

2010/11/05
		- added support for .ke domains

2010/09/20
		- released version 4.2.1
		- provided default object data for unsupported domains

2010/09/16
		- fixed .si handler

2010/08/26
		- UseServer can now be used for ip addresses

2010/08/24
		- removed dangerous exec call

2010/08/23
		- improved extra whois parameters for better
		support of .jp whois
		- added handler for .jp
		- added handler for .co
		- added ipv6 support

2010/08/10
		- joined common whois field list
		- some minor fixes
		- testsuite can now test specific handlers
		- fixed iana handler
		- improved generic_parser_b
		- removed .es handler

2010/07/27
		- better AS support
		- ip handlers rewritten

2010/07/21
		- added dnssec info to domain object
		- parser improved
		- better support for some non utf-8 servers
		- removed buydomains handler
		- added afternic handler
		- fixes for many handlers

2010/07/20
		- fixed arin new query format
		- better ip refferal whois follow-up
		- avoid double rwhois queries

2010/05/20
		- added gtld handlers for domainpeople,dremhost,fastdomain,
		  marmonitor & names4ever (by Brandon Whaley)

2010/04/28
		- fixed gtld handler: some registrars give no information
          on pendingdelete domains that could appear as unregistered
		- fixed bug #2991358 (owner not correctly set for .at domains)
		- fixed bug #2991270 (added extra incorrect nameserver
          on .eu domains)
        - fixed bug #2991265 (.org organization not parsed)

2010/04/13
		- added .ly handler
		- added .fj handler

2009/12/29
		- released version 4.2.0
		- added handler for .tel
		- new easy_parser funtion applied to many handlers
		- fixes for several handlers
		- stargateinc handler moved to namevault
		- itsyourdomain seems to be now tucows
		- domainbank is now handled by dotster
		- domaincontender is now assorted
		- fixed bug #2888773 validip function uses undefined variable
		- improved .eu domain registration status detection
		- fixes for html nice output and utf-8 support

2008/10/10
		- fixed bug #2153003
		- fixed bug #2153380 Bad info for joker.com domain owners

2008/09/07
		- check network nserver too
		- added suport for spanish dates
		- fixed ws handler

2008/08/29
		- fixed 'bold' regex and removed extra
          blank lines in showHTML result

2008/08/28
		- fixed namespace in whois.ip.lib.php
		- allow to specify full url in showHTML result

2008/08/20
		- added .ve handler by jlchafardet
		- fixed some handlers reporting 'bill' instead of 'billing'
		- added helper functions for some handlers
		- fixed .au handler

2008/08/11
		- fixed .es handler

2008/07/08
		- added handler for .su

2008/06/30
		- added handler for .fi

2008/06/26
		- added handler for .asia

2008/06/25
		- fixed hangup bug on some non-responding rwhois
		  servers (read result changed to non-blocking)

2008/06/16
		- added support & handler for .me

2008/06/16
		- fixed .fr handler

2008/06/11
		- fixed .cz handler registered date
		- fixed .fr handler
		- added .ro handler

2008/05/28
		- added handler for .it
		- added handler for .fr

2008/05/17
		- Added support for .ve
		- Released version 4.1.3

2008/05/11
		- fixed whois.museum

2008/05/09
		- do not use handlers on error

2008/05/04
		- improved nameserver detection (again)
		- fixed whois.pl, whois.gtld.nominalia,
	      whois.gtld.onlinenic, whois.ovh
		- removed test for informe.ws
		- minor fix to whois.gtld.enom
		- minor chages to other handlers

2008/04/29
		- improved nameserver detection (again)
		- fixes & improvements on whois.mx

2008/04/28
		- whois.za.php renamed to whois.zanet.php
		- added support & handler for .org.za
		- added handler for .co.za
		- minor improvemts on whois.client.php to allow
		  handlers for second level domains
		- improved nameserver detection
		- minor fix to .ie handler

2008/03/05
		- dotregistrar is now part of dotster
		- fixes in date parser
		- .cz handler update
		- fixed .ch whois server detection

2007/12/21
		- fixed uninitialized variable in example.php
		- fixes in publicdomainregistry and uk handlers
		- improved regex for html output
		- added support for centralnic domains
		- added handler for .pt and .ae (pacth #1709470)
		- fixed bug #1761156
		- applied patch #1749389

2007/05/30
		- removed support for .gr domains

2007/05/24
		- uniform way to specify query array

2007/05/09
		- fixed reporting of ip query information

2007/05/04
		- fixes to ip handler and APNIC ip handler

2007/05/03
		- minox fix in whois.gtld.publicdomainregistry.php
		- removed unused handler whois.gtld.directi.php

2007/04/30
		- fixed tucows/opensrs gtld handler detection
		- more improvements and cleanup of whois.parser.php
		- added gtld handler for Fabulous

2007/04/29
		- several improvments on whois.parser
		- several handlers fixed to work with improved parser
		- added gtld handler for NameKing

2007/04/27
		- rearranged regyinfo array
		- better info reporting on ip whois

2007/04/26
		- restrict .com/.net searches to domains
		- regyinfo now contains a list of all servers
	      servers contacted in key 'servers'
		- improvements in contact data detection in
		  whois.parser
		- added gtld handler for OnlineNIC

2007/04/24
		- added gtld handler for Wild West Domains
		- utf8 fixes in example.php

2007/04/23
		- added gtld handler for RRPPROXY

2007/04/21
		- added gtld handler for NICCO

2007/04/20
		- fixes and improvments in .pl handler
		- improved IDNA support

2007/04/18
		- fixed warnings in nicline and tmagnic gtld handlers
		- added support for IDNA (internationalized) domains names
		  as defined in RFC3490, RFC3491, RFC3492 and RFC3454
		  using Matthias Sommerfeld idna_convert class

2007/04/17
		- allow easy plugin for new gtld handlers
		- minor improvement to testsuite.php
		- fixed .se handler
		- namesdirect has joined with dotster
		- fixed tmagnic gtld handler

2007/04/16
		- added basic support for .bz
		- whois.info.php cosmetic changes
		- added .ru handler
		- support for multiple status lines in whois.org.php and
          whois.gtl.php
		- removed whois.gtld.chdom handler
		- allow easy plugin for new country handlers
		- minor improvement to whois.client.php and
          whois.parser.php
		- added gtld handler for OVH

2007/04/06
		- fixed error in whois.ip.php

2007/03/30
		- minor fix on whois.ip.php

2007/03/28
		- some handlers where not seeting rawdata

2007/03/19
		- Fixed nic.br ip handler detection

2007/03/05
		- fixed .cat registered yes/no detection

2007/03/02
		- minor fix to .eu handler
		- fixes in arin ip handler

2007/02/06
		- changed the way gTLD handlers are detected

2006/12/21
		- fix/improvement for register.com handler

2006/12/20
		- Released version 4.1.2

2006/12/19
		- minor fixes to testsuite.php, whois.parser.php,
		  whois.gtld.joker.php, whois.gtld.enom.php and
		  whois.gtld.tvcorp.php
		- updated .nl handler
		- enom has mixed with bulregister, so bulkr
		  gtl handler has been removed

2006/12/18
		- minor fixes to whois.ca.php, whois.es.php,
		  whois.gtld.iana.php, whois.gtld.opensrsnet.php,
		  whois.ip.apnic.php, whois.biz.php,
		  whois.gtld.psiusa.php, whois.parser.php,
		  and whois.ch.php
		- updated .lthandler
		- added support and handler for .jobs

2006/09/29  David Saez <david@ols.es>
		- Fixed .in whois server name
		- Added handler for .in
		- Added gtld handler for psiusa (Patch #1539553)
		- Fixed .za.net handler
		- testsuite domain listed updated
		- ip handler improvments from bug #1533099

2006/09/07  David Saez <david@ols.es>
		- Fixed register.com owner detection

2006/08/02  David Saez <david@ols.es>
		- Fixed bug #1495871: failed to open stream

2006/07/25  David Saez <david@ols.es>
		- enabled again .es handler

2006/06/23  David Saez <david@ols.es>
		- fixed warning in whois.ip.afrinic
		- added handler for .nz
		- disabled .es handler
		- Released version 4.1.1

2006/06/19  David Saez <david@ols.es>
		- better handling of errors in whois.ip.php

2006/06/12  David Saez <david@ols.es>
		- More PHP5 friendly (from Bug #1502777)
		- rawdata reflects all rwhois output
		- added suport and handler for .mobi

2006/05/31	David Saez <david@ols.es>
		- Fixed bug #1495389

2006/05/16  David Saez <david@ols.es>
		- added handler for .sc (thanx to
		  Hans-Peter Kohnle)

2006/05/08  David Saez <david@ols.es>
		- fixed exmaple.php
		- fixed .pl and .de handler

2006/04/29  David Saez <david@ols.es>
		- improved .edu handler
		- testsuite finished
		- proxy support
		- added template for example.php
		
2006/04/28 David Saez <david@ols.es>
		- fixed special non handled domains support
		- added not supported domain .cy
		- fixed typo in test.txt
		- fixed directi handler detection
		- improved whois.parser
		- fixed joker handler
		- minor fix to namejuice handler
		- fixed krnic handler

2006/04/08  David Saez <david@ols.es>
		- Added handler for .eu
		- Minor fix to example.php
		- Improved HTML output

2006/04/05  David Saez <david@ols.es>
		- Added support for EPP status (bug #1463866)

2006/04/03  David Saez <david@ols.es>
		- fixed timestamp style date detection

2006/03/29  David Saez <david@ols.es>
		- fixed bad rwhois server/port detection
		- added optional suport for non ICANN tld's

2006/03/24  David Saez <david@ols.es>
		- added handler for NAMESDIRECT
		- fixed register.com handler
		
2006/03/21 David Saez <david@ols.es>
		- Fixed problems with some domains registered
		  at enom

2006/03/20  David Saez <david@ols.es>
		- Aplied fix to bug #1453935

2006/03/19 David Saez <david@ols.es>
		- added gtld handler for namejuice
		  (thanx to Robert Apgood <rob@carpelaw.com>)
		- example.php is now XHTML 1.0 compliant

2006/03/14 David Saez <david@ols.es>
		- fixed case detection on whois.parser.php

2006/03/10 David Saez <david@ols.es>
		- added handler for .edu

2006/03/07 David Saez <david@ols.es>
		- added gtld handler for alldomains
		- more improvemnts on whois.parser.php

2006/03/06 David Saez <david@ols.es>
		- added gtld handler for nominalia

2006/03/05 David Saez <david@ols.es>
                - fixed .de handler
		- .ca handler fixed and updated

2006/03/03 David Saez <david@ols.es>
		- added handler for gtld domaincontender.com

2006/03/02  David Saez <david@ols.es>
                - added handler for .pl and .ie
		- minor fixes in whois.parser.php

2006/02/27  David Saez <david@ols.es>
		- minor fixes for non-existing .es domains
		- fixed ip2long PHP5 compatibility
		- fixed sponsor detection on opensrsnet handler

2006/02/13  David Saez <david@ols.es>
		- fixed nserver detection in whois.es.php

2006/02/03  Released phpWhois 4.1.0

2006/02/03  David Saez <david@ols.es>
		- fixed README documentation
		- minor fixes to some handlers

2006/02/01  David Saez <david@ols.es>
		- fixed README documentation
		- improved .au handler for user with
		  whois-check.ausregistry.net.au
		- added testsuite for verifying handlers

2006/01/31  David Saez <david@ols.es>
		- fixed lookup error on .co.za domains
		- minor fix to whois.pareser.php

2006/01/27  David Saez <david@ols.es>
		- added deep_whois feature to get faster but
		  less acurate results

2006/01/24  David Saez <david@ols.es>
		- minor fixes to .es handler

2006/01/20  David Saez <david@ols.es>
		- changed .es http based whois server
		- added function to set specific whois servers
		- updated .es handler
		- formating fixes in whois.parser.php
		- added handler for .cat

2006/01/18  David Saez <david@ols.es>
		- minor fixes in enom handler

2006/01/13  David Saez <david@ols.es>
		- updated .uk handler

2005/12/11  David Saez <david@ols.es>
		- fixed some warnings in .de handler and
		  added timeout detection

2005/12/10  David Saez <david@ols.es>
		- fixed html output broken links

2005/12/01  David Saez <david@ols.es>
		- fixed php warning with limbo domains in netsol

2005/11/21  David Saez <david@ols.es>
		- added support for .pr domains
		- fixed warning in whois.ip.afrinic.php
		- added detection for netblocks transferred
		  from RIPE to AFRINIC

2005/11/17  David Saez <david@ols.es>
		- added support for .mt domains

2005/11/14  David Saez <david@ols.es>
		- avoid some warnings on whois.gtld.bulkr.php

2005/11/11  David Saez <david@ols.es>
		- removed support for .es domains
		- some fixes in .uk handler

2005/11/07  David Saez <david@ols.es>
		- added handler for .int domains
		- added support for some other domains

2005/11/06  David Saez <david@ols.es>
		- added support & handler for .travel
		- showHTML made a bit more flexible

2005/10/31  David Saez <david@ols.es>
		- better windows based php detection
		- fixed registro.br detection

2005/10/21  David Saez <david@ols.es>
		- added handler for Directi
		- added handler for .cz domains

2005/10/20  David Saez <david@ols.es>
		- added handler for gtld IANA
		- updated .org handler

2005/10/15  David Saez <david@ols.es>
		- added missing example for .ag and .name
		- added multiple abuse email address detection
		  in arin ip queries
		- avoid adding empty fields in whois.parser.php
		- added support and handler for .pro domains

2005/10/14  David Saez <david@ols.es>
		- clean some messy ripe records
		- added handler for .name

2005/10/12  David Saez <david@ols.es>
		- added compatibility with PHP versions prior 4.3.0

2005/10/11  David Saez <david@ols.es>
		- fixed warning for non-existant .es domains

2005/10/10  David Saez <david@ols.es>
		- fixed some short tags in example.php,
		  fixed queries to .net whois server,
		  added support for .pe domains,
		  fixed .se registration detection,
		  added requirements section in README,
		  fix to let it work with PHP 4.1.0 - 4.3.1,
		  installation clarified
		  thanx to Speedywise

2005/10/09  Released phpWhois 4.0.1
		- some files where missing !!

2005/10/04  David Saez <david@ols.es>
		- fix for address reporting
		- added handler for .coop

2005/09/30  David Saez <david@ols.es>
		- fix for .museum handler
		- added handler for .aero
		- minor fix for date extraction in whois.parser.php

2005/09/29  David Saez <david@ols.es>
		- added handler for .museum

2005/09/27  David Saez <david@ols.es>
		- minor formating fix
		- added handler for .lt

2005/09/13  David Saez <david@ols.es>
		- better error handling in whois.gtld

2005/09/05  David Saez <david@ols.es>
		- minor code cleaup on whois.gtld.php
		- added better support for errors
		- added hanlder for .ag
		- added ip detection for HTML output
		- country tld revision [ax-bx]

2005/09/01  Released phpWhois 4.0.0

2005/08/31  David Saez <david@ols.es>
		- changed behaviour of whois.utils.php
		- changed url disclaimer
		- added GPL license file
		- whois.gtld.bulkr.php rewritten
		- last minute fixes

2005/08/30  David Saez <david@ols.es>
		- changed generic_whois_b item parameter array
		- fixes & improvments for rwhois
		- AS detection, added regyinfo.type subkey
		- added abuse contact detection for ripe
		- fixes for .se
 
2005/08/29  David Saez <david@ols.es>
		- changed gif icon for a new png one
		- recovered better example.php from old
                  distribution
		- utils.whois renamed to whois.utils.php
		- removed obsolete FAQ item
		- added nice HTML output capabilities to
		  whois.utils.php
		- fixed whois.ip.php
		- added extra abuse email address detection
                  for whois.ip.php
		- addeed rwhois recognition for afrinic

2005/08/26  David Saez <david@ols.es>
		- code cleanup and formatting
		- added support form Referral Whois (rwhois)
                  as per RFC 1714/2167, support is limited, non
                  recursive and only for ARIN ip space

2005/08/19  David Saez <david@ols.es>
		- fixed some bad includes

2005/07/29  David Saez <david@ols.es>
		- fixed problem with lastest changes in whois.ip

2005/07/28  David Saez <david@ols.es>
		- modified $query parameter for parse function

2005/07/27  David Saez <david@ols.es>
		- genutil, generic2 and getdate moved to
		  whois.parser.php
		- cli_example.php renamed to example.cli.php
		- added handler.template.php
		- disclaimer updated
		- updated README file
		- some improvments for AS queries
		- some handlers reported zcode instead of pcode
		- added support for AfriNIC (ip whois)
		- updated HANDLERS documentation
		- added support for CHINESEDOMAINS

2005/07/26  David Saez <david@ols.es>
		- added handler for za.org & za.net, thanx to
 		  luca@clamav.net
		- generic3.whois code moved to whois.parser.php

2005/07/25  David Saez <david@ols.es>
		- removed unused file denic.whois
		- added support for za.net and za.org, thanx
                  to luca@clamav.net
		- rewritte of .uk handler
		- whois client code moved to whois.client.php
		- class inheritence revised
		- generic.whois moved to whois.parser.php

2005/07/22  David Saez <david@ols.es>
		- added CDIR to inetnum conversion for ip whois and
		  fixed brnic detection
		- changed naming schema for gtld handlers

2005/07/19  David Saez <david@ols.es>
		- changes on methods and variables of Whois class

2005/07/17  David Saez <david@ols.es>
		- changed naming schema for country handlers

2005/07/16  David Saez <david@ols.es>
		- normalized expired/created/chaged dates
		- report non existant dns servers
		- improved getdate.whois
		- fixed benic.whois
		- improvements to genric whois handling
		- improvments & fixes to esnic, denic and brnic
                  handlers
		- added configurable timeout for sockec communications
		- changed naming schema for ip handlers

2005/04/28  David Saez <david@ols.es>
		- Fixed .fm handling
		- normalized expired/created/chaged dates
		- changed the way nservers are normalized
		- some fixes
		- adde CLI mode example

2005/03/14  David Saez <david@ols.es>
		- added handler for TV CORPORATION

2005/03/03  David Saez <david@ols.es>
		- minor fix to main.whois
		- added some object fields when not set
		- fixed handling of .tv

2005/03/02  David Saez <david@ols.es>
		- fixed SRSPlus detection
		- applied patch [ 981413 ] Whois Parameter Array
		  thanx to mwelters
		- added better reporting on nameservers
		- better email reporting on generic3.whois

2005/03/01  David Saez <david@ols.es>
		- fixed Network Solutions detection
		- ordered list of handlers in gtld.whois
		- added handler for Moniker
		- added handler for Innerwise
		- added handler for Stargate
		- added handler for Cronon
		- added handler for Joker
		- fixed scripts using php short tags
		  thanx to rpm@keynetics.com
		- added handler for Schlund

2004/08/06  David Saez <david@ols.es>
		- fixed denic.whois when domain does not
		  exist, thanx to bjoern@xrow.de

2004/04/24  David Saez <david@ols.es>
		- added .is handler
		- added some notes about generic support functions
		  in HANDLERS

2004/04/23  David Saez <david@ols.es>
		- Fixed ending tag in all files

2004/04/22  David Saez <david@ols.es>
		- added handler for .us , thanx to
		  snguyen@mbaassociation.org
		- correctly sets regyinfo.whois
		- added hack for .net.au , thanx to
		  thill@gumnut.com.au
		- implemented request id 757465
		- fixed bug 690623
		- fixed bug 804595
		- added feature request 759788
		- added .bg http whois mserver
		- added .hu handler

2004/04/21  David Saez <david@ols.es>
		- fixed small bug in netsol.whois
		- improvments and fixes to gtld.whois, thanx to
		  snguyen@mbaassociation.org

2004/02/11  David Saez <david@ols.es>
		- handles R120-LROR, thanx to DavHolle

2003/11/22  David Saez <david@ols.es>
		- fix for .tv domains

2003/10/27  David Saez <david@ols.es>
		- minor improvments to main.whois
		- fix for .in domains

2003/10/01  Ross Golder <ross@golder.org>
		- Released phpWhois version 3.0.6

2003/09/20  David Saez <david@ols.es>
		- minor improvment to esnic.whois

2003/09/13  David Saez <david@ols.es>
		- minor improvment to org.whois

2003/09/12  David Saez <david@ols.es>
		- added gtld handler for Arsys nicline
		  thanx to cgalvez@espaciowww.com
		- minor fixes to main.whois and gtld.whois

2003/09/09  David Saez <david@ols.es>
		- fixed some warning when ip is banned
		  on domainbank.whois
		- main.whois also sets regyinfo.whois on http
		  queries
		- rewrite of esnic.whois

2003/09/08  David Saez <david@ols.es>
		- rewrite of cnnic.whois
		- some fixes to wsnic.whois
		- some fixes to gtld.whois and generic3.whois
		- added handler for Godady and Domain Bank
		- minor improvment to main.whois and generic2.whois
		- added handler for .org

2003/09/06  David Saez <david@ols.es>
		- Added handlers for .cn and .ws
		  thanx to zingfharn@fastmail.fm
		- Fixed main.whois to allow https queries
		- Enabled .es queries but handler remains
                  disabled because needs total rewrite

2003/08/04  David Saez <david@ols.es>
		- Temporary deactivation of .es handler due to
		  changes in .es registry whois system
		- Fixed denic.whois, thanks to 
                  Gulibert@NetGameZone.de

2003/06/30  David Saez <david@ols.es>
		- added handler for .be, thanx to 
		  onveilig@hotmail.com

2003/06/04  Ross Golder <ross@golder.org>
		- Removed a blank line preventing headers from
		  being sent.

2003/04/25  David Saez <david@ols.es>
		- added support for web based whois for
		  .tc, .vg, .ms, .gs and .tf domains
 
2003/04/19  David Saez <david@ols.es>
		- fixed problem with whois.crsnic.net which
		  causes some domains like hotmail.com and
		  yahoo.com not to resolve, thanx to
		  asajith@users.sourceforge.net for reporting
		  this issue, also some improvments have been
		  made to help diagnose problems like that in
		  the future

2003/04/11  David Saez <david@ols.es>
		- added gtld handler for SRSPlus

2003/04/07  Mark Jeftovic <markjr@easydns.com>
		- fix for missing checkdnsrr function in windows

2003/04/04  David Saez <david@ols.es>
		- added handler for .fm

2003/03/30  David Saez <david@ols.es>
		- recovered 'powered by phpWhois' logo
		- added handlers for directnic and buydomains
		- minor improvment to generic3.whois
		- minor fixes to bripw.whois

2003/03/26  David Saez <david@ols.es>
		- some improvments on generic3.whois
		- added handler for ascio (com/org)

2003/03/22  David Saez <david@ols.es>
		- referrer correction and normalization in some handlers
		- removed unused handler cdnnet.whois

2003/03/22  Ross Golder <rossigee@users.sourceforge.net>
		- Release 3.0.4 available now

2003/03/17  David Saez <david@ols.es>
		- chnic.whois & nlnic.whois rewritten
		- minor fix and improvment on generic3.whois
		- added nameserver detection to dotregistrar.whois
		- minor fix on info.whois
		- fixed bripw.whois
		- bulkregstercom.whois fixed and updated to common
		  object model

2003/03/16  David Saez <david@ols.es>
		- mxnic.whois updated to common object model
		- recovered brnic.whois and added bripw.whois
		  which was implemented over brnic.whois by
		  mistake
		- fixed netsol.whois

2003/03/12  Ross Golder <rossigee@users.sourceforge.net>
		- Minor corrections and a note about coding style
		  on HANDLERS

2003/03/07  David Saez <david@ols.es>
		- added lacnic.whois
		- added file HANDLERS
		- minor fixes to README

2003/03/05  David Saez <david@ols.es>
		- implemented krnic.whois
		- minor improvments to generic3.whois

2003/03/04  David Saez <david@ols.es>
		- improvments on ripe.whois
		- implemented arin.whois and brnic.whois
		- added ip's for testing on ipw.whois

2003/03/03  David Saez <david@ols.es>
		- some fixes to ip whois
		- some fixes to uknic.whois
		- implemented ripe.whois
		- improved code for html2text for web based whois

2003/02/26  David Saez <david@ols.es>
		- common object model changes in some handlers
		- removed warning in gtld.whois when domain does not exist
		- core.whois fixed and updated to common object model
		- added corenic .org handle to gtld.whois

2003/02/25  David Saez <david@ols.es>
		- added interdomain .org handle
		- interdomain.whois updated to common object model

2003/02/19  David Saez <david@ols.es>
		- added dotregistrar .org handle
		- some improvments to generic3.whois
		- registercom.whois updated to common object model

2003/02/18  David Saez <david@ols.es>
		- added dotster .org handle
		- some improvments to generic3.whois
		- dotster.whois & registercom.whois updated to common object model

2003/02/16  David Saez <david@ols.es>
		- improved generic.whois, update all handlers that use it
		- now it's possible to also query http based whois
		- added .es handler (http)
		- some improvments on generic3.whois
		- enom.whois fixed and updated to common object model
		- added enom .org handle to gtld.whois

2003/02/15  David Saez <david@ols.es>
		- added generic3.whois with functions to parse whois output
		- added disclaimer to generic.whois and generic2.whois
		- opensrsnet.whois updated to common object model
		- added mxnic.whois, thanx to torfinn@nome.no

2003/02/10  David Saez <david@ols.es>
		- inwwcom.whois updated to common object model
		- added inwwcom org handle to gtld.whois
		- gtld.whois now can get the name of the org registrar
		- minor fixes to generic2.whois

2003/02/09  Ross Golder <ross@golder.org>
		- updated to do a 'whois-servers.net' DNS lookup to determine
		  the tld whois server to query

	    David Saez <david@ols.es>
		- netsol.whois & gtld.whois updated to common object model
		- fixed some warnings in main.whois

2003/01/29  David Saez <david@ols.es>
                - fixed nicse.whois and updated to common object model

2003/01/27  David Saez <david@ols.es>
		- fixed nunames.whois and updated to common object model

2003/01/26  David Saez <david@ols.es>
		- fixed lunic.whois and updated to common object model
		- neulevel.whois changed to use generic2.whois
		- some minor fixes on info.whois

2003/01/25  David Saez <david@ols.es>
		- info.whois updated to common object model

2003/01/19  David Saez <david@ols.es>
		- fixed denic.whois

2003/01/18  David Saez <david@ols.es>
		- added nlnic.whois, thanx to Matthijs Koot <koot@cyberwar.nl>
		- fixed some warnings on generic.whois
		- fixed double processing on atnic.whois

2002/12/16  David Saez <david@ols.es>
		- updated aunic.whois
		- improved generic.whois & generic2.whois
		- fixed uninitialized variable in utils.whois

2002/10/16  David Saez <david@ols.es>
		- Updated uknic handler to new Nominet UK whois output
		- Added handler for .biz
		- Added support to ipw.whois for BRNIC, KRNIC, TWNIC and LACNIC
		- Some handlers updated to new common object model
		- Added generic.whois and generic2.whois with parse functions
		  for two kinds of whois output commonly used

2002/10/11  Ross Golder <ross@golder.org>
		- Merged in as many useful patches as possible (supplied by Mark)
		- Re-indented the classes for clarity
		- Attempted to add comments to as much code as possible

2001/02/28
		-batch add of many updates
		-uknic.whois updated by David Saez Padros 
		-added dotster and chnic for .ch and .li, also by David Saez Padros
		-.at whois server now whois.nic.at
		
2000/12/12
v2.3	-PHP4 BUG IS FIXED!!!! Very special thanks to all who submitted
		fixes, used one provided by Stephen Leavitt 
		<stephen_j_leavitt@hotmail.com> as it was the easiest and backwards
		compatible to PHP3
		-added Enom handler, also by Stephen Leavitt 
		<stephen_j_leavitt@hotmail.com>
		-changed .ca whois to whois.cira.ca, using same handler for now.
2000/08/14
		-added brnic.whois country handler
		-major revision of servers.whois, many adds (crossreferenced
		against geektools list at 
		http://www.geektools.com/dist/whoislist.gz)
		-dropped all ORSC TLD's, either their whois servers weren't
		working or it was clear there was no functioning registry
		if they were. (From here on in we stick to the IANA
		legacy root TLD's) 
2000/08/07
v2.2-3		-gtld.whois, "TUCOWS.COM INC." now, "TUCOWS.COM, INC."
		an unannounced change by the NSI registry once again
		breaks scripts all over the world...(thanks to 
		Fred Andrews <fandrews@Technologist.com> for the report
		and fix on this)
		-servers.whois, added .ke Kenyan whois server, thanks
		to "Peter Anampiu" <Anampiu@4bil.net> for digging that up.:x

2000/05/27
v2.2-2		-ouch! params in implode() are backwards 

2000/04/06
v2.2-1		-new classes for bulkregister, openSRS and melbourneIT
		by Jeremiah Bellomy <jeremiah@emphasys.net>

2000/03/16
v2.1-4		-servers.whois, added .st

2000/03/08
v2.1-4		-servers.whois, fixed .no address, added .as

2000/01/26
v2.1-4
main.whois	-fixed Connect() so it wouldn't attempt to connect
		to an unset server (Query["server"] is null on
		pass 2 if domain isn't in the registry whois)
		-added rudimentry "not found" code to sample script

2000/01/02
v2.1-3		
main.whois	-fixed GetTld() so "churchuk.com" 's tld wouldn't
		mistakenly be set to nominet's "uk.com" tld.
		-fixed Lookup() was always using char by char reads
		regardless of $this->BUFFER value
servers.whois 	-added nominet's se.com, se.net and no.com

2000/01/01
2.1-2
main.whois	-fixed Process() so it would only include the handler if
		it wasn't already defined. Trying queries inside a loop
		would fail on the second iteration.

